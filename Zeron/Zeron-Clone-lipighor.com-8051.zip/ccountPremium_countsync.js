/*
 * File: countsync.js
 * Depends: jquery-x.x.x.min.js
 * Desc: AJAX enabled java script responsible for parse and sync 'like' or 'download' counts from or to backend apache-mod-php.
 * Warning: Put the file end of a html page, the full page needed to be loaded in DOM.
 * Created: 05/01/2019 12:54:36 PM
 * Modified: 07/01/2019 03:33:08 AM
 * Author : Rupam (Cyberdev)
 */

//AJAX function for parsing response
function showResponse(response,ecs)
{
	console.log(ecs + ' : ' + response);
	var responseContainer = document.querySelector(ecs);

	responseContainer.innerHTML = response;
}

//AJAX function for get response body handling
function getResponseHandler(ecs,eventObj)
{
	var request = eventObj;

	if (request.readyState != 4)
	{
		return;
	}

	if (request.status == 200)
	{
		var response = request.responseText;
		var bnResponse = parseInt(response).toLocaleString("bn-BD");
		showResponse(bnResponse,ecs);
	}
	else if (request.status == 500)
	{
		showResponse('Backend busy!',ecs);
	}
	else if (request.status == 404)
	{
		showResponse('Backend not connected!',ecs);
	}
}

//AJAX function for send response body handling
function sendResponseHandler(eventObj)
{
	var request = eventObj;

	if (request.readyState != 4)
		return;
}

//AJAX function for getting like(s)/download(s) count
function getCount(uri,ecs)
{
	var request = new XMLHttpRequest();
	var url = 'ccountPremium/';

	console.log(window.location.pathname);
	
	url += '?' + uri;
	ecs = '.' + ecs;

	request.open('GET', url);
	request.addEventListener('readystatechange', function(){var eventObj = this; getResponseHandler(ecs,eventObj);});
	//request.addEventListener('readystatechange', getResponseHandler.bind(ecs));
	request.send();
}

//AJAX function for sending like(s)/download(s) count
function sendCount(uri,ecs)
{
	var request = new XMLHttpRequest();
	var url = 'ccountPremium/';
	
	url += '?' + uri;
	gtEcs = ecs;
	ecs = '.' + ecs;
	
	request.open('GET', url);
	//request.addEventListener('readystatechange', function(){var eventObj = this; sendResponseHandler(eventObj);});
	request.addEventListener('readystatechange', function(){var eventObj = this; getResponseHandler(ecs,eventObj);});
	request.send();
	
	//uri += 'Fetch';

	//getCount(uri,gtEcs);
}

//AJAX function for check if variable is undefined
/*if (typeof internalEcs === 'undefined')
{
	var internalEcs = '';
}*/

//AJAX function for setting up trigger element
/*function setupTrigger()
{
	var triggerElement = document.querySelector('.ccountTrigger');

	triggerElement.addEventListener('click', getCount);
}*/

//setupTrigger();

//AJAX function for syncing like(s)/download(s) count
/*
function syncCount()
{
	var refreshContainer = document.querySelector('.ccountData');
	refreshContainer.refresh();
}

syncCount();
*/

//AJAX function for get response body handling
/*function getResponseHandler(ecs,eventObj)
{
	var request = eventObj;
	if (typeof retryReq === 'undefined')
	{
		var retryReq = 0;
	}

	if (request.readyState != 4)
	{
		retryReq++;

		if (retryReq < 4)
		{
			getResponseHandler(ecs,eventObj);
		}
		else
		{
			retryReq = 0;
			return;
		}
	}

	if (request.status == 200)
	{
		var response = request.responseText;
		showResponse(response,ecs);
	}
	else if (request.status == 500)
	{
		showResponse('Backend busy!',ecs);
	}
	else if (request.status == 404)
	{
		showResponse('Backend not connected!',ecs);
	}
}
*/