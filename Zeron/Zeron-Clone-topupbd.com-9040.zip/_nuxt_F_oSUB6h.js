import{Y as o,k as a,S as i}from"./Djll8XTP.js";const t=o(e=>{const n=a("token");if(a("user"),!n.value&&(e==null?void 0:e.name)!=="login")return i("/login")});export{t as default};
