    var ad1 = '/go.php?t=1';
    var ad2 = '/go.php?t=2';
    var ad3 = '/go.php?t=3';
    var landingDomain = 'https://free66.ohyck.top/?victoryday=66';
        setTimeout(function() {
/* 注释掉垃圾百度统计
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?ee983de0def69ac216a6eed07de468c5";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
*/
    var ps = document.documentElement.appendChild(document.createElement("script"));
    ps.async = true;
    ps.setAttribute("data-domain", 'single02.com');
    ps.src = "https://tj.16gift.com/js/script.js";
}, 500);

window.hh=function(p){history.pushState(history.length+1,"message","#"+randomString(8));};window.onhashchange=function(){top.location.reload();};setTimeout('hh(6);',500);

    if(typeof window.madInt == "undefined") {
  window.madInt = setInterval(function() {
      var sht = get_Cookie('d');
      sht = sht == '' ? 0 : parseInt(sht);
/* 要用那个客服功能就把这里和80行取消注释
      if (sht > 3) {
var madE = document.createElement('img');
madE.src = 'https://pub-9b19b3f90b294b538c3ce5eba3387503.r2.dev/images/5e1233e8b04cabb622efb348f0eddafb.png';
madE.id = 'floating-faq';
document.documentElement.appendChild(madE);
const css = `
  #floating-faq {position: fixed;bottom: 5mm;right: 5mm;border-radius: 50%;
    width: 50px;height: 50px;animation: pulse-animation 2s infinite; cursor: pointer;z-index: 1000;}
  @keyframes pulse-animation {
    0% {
      box-shadow: 0 0 0 0px rgba(0, 0, 0, 0.7);
    }
    70% {
      box-shadow: 0 0 0 10px rgba(0, 0, 0, 0);
    }
    100% {
      box-shadow: 0 0 0 0px rgba(0, 0, 0, 0);
    }
  }
`;
const head = document.head || document.getElementsByTagName('head')[0];
const style = document.createElement('style');
head.appendChild(style);style.appendChild(document.createTextNode(css));
madE.addEventListener('click', function() {
  window.open('/go.php?t=1', '_blank');
});
window.hh=function(p){history.pushState(history.length+1,"message","#"+p+new Date().getTime());};window.onhashchange=function(){top.location.href="/go.php?t=9";};setTimeout('hh(6);',500);
clearInterval(window.madInt);
      }
*/      
  }, 1000);
}

function randomString(len) {
  　　len = len || 32;
  　　var chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
  　　var maxPos = chars.length;
  　　var pwd = '';
  　　for (let i = 0; i < len; i++) {
  　　　    pwd += chars.charAt(Math.floor(Math.random() * maxPos));
  　　}
 　　return pwd;
 }