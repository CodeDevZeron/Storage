class VideoDownloader {
    constructor() {
        this.videoUrlInput = document.getElementById('videoUrl');
        this.pasteBtn = document.getElementById('pasteBtn');
        this.downloadBtn = document.getElementById('downloadBtn');
        this.qualitySelect = document.getElementById('qualitySelect');
        this.loadingModal = document.getElementById('loadingModal');
        this.errorModal = document.getElementById('errorModal');
        this.errorTitle = document.getElementById('errorTitle');
        this.errorMessage = document.getElementById('errorMessage');
        this.errorCloseBtn = document.getElementById('errorCloseBtn');
        this.errorRetryBtn = document.getElementById('errorRetryBtn');
        this.resultsSection = document.getElementById('resultsSection');
        this.backBtn = document.getElementById('backBtn');
        this.videoTitle = document.getElementById('videoTitle');
        this.videoThumbnail = document.getElementById('videoThumbnail');
        this.videoDuration = document.getElementById('videoDuration');
        this.videoQuality = document.getElementById('videoQuality');
        this.downloadOptions = document.getElementById('downloadOptions');
        this.platformsGrid = document.getElementById('platformsGrid');
        this.successToast = document.getElementById('successToast');
        this.toastMessage = document.getElementById('toastMessage');
        
        this.currentDownloadData = null;
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.setupPlatformIcons();
        this.loadPlatforms();
    }
    
    bindEvents() {
        // Paste from clipboard
        if (this.pasteBtn) {
            this.pasteBtn.addEventListener('click', () => this.pasteFromClipboard());
        }
        
        // Download button
        if (this.downloadBtn) {
            this.downloadBtn.addEventListener('click', () => this.processDownload());
        }
        
        // Enter key in input
        if (this.videoUrlInput) {
            this.videoUrlInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.processDownload();
                }
            });
        }
        
        // Error modal
        if (this.errorCloseBtn) {
            this.errorCloseBtn.addEventListener('click', () => {
                this.errorModal.classList.remove('active');
            });
        }
        
        if (this.errorRetryBtn) {
            this.errorRetryBtn.addEventListener('click', () => {
                this.errorModal.classList.remove('active');
                if (this.currentDownloadData) {
                    this.processDownload(this.currentDownloadData.url, this.currentDownloadData.quality);
                }
            });
        }
        
        // Back button
        if (this.backBtn) {
            this.backBtn.addEventListener('click', () => {
                this.resultsSection.style.display = 'none';
                document.querySelector('.hero-section').scrollIntoView({ behavior: 'smooth' });
            });
        }
        
        // Close modal on outside click
        [this.loadingModal, this.errorModal].forEach(modal => {
            if (modal) {
                modal.addEventListener('click', (e) => {
                    if (e.target === modal) {
                        modal.classList.remove('active');
                    }
                });
            }
        });
        
        // Close toast after 3 seconds
        if (this.successToast) {
            this.successToast.addEventListener('click', () => {
                this.hideToast();
            });
        }
    }
    
    setupPlatformIcons() {
        const platformIcons = document.querySelectorAll('.platform-icon');
        platformIcons.forEach(icon => {
            icon.addEventListener('click', () => {
                const platform = icon.classList[1];
                if (this.videoUrlInput) {
                    this.videoUrlInput.placeholder = `Paste ${platform} video link here...`;
                    this.videoUrlInput.focus();
                    
                    // Add animation
                    icon.style.transform = 'scale(1.2)';
                    setTimeout(() => {
                        icon.style.transform = 'scale(1)';
                    }, 300);
                }
            });
        });
    }
    
    async loadPlatforms() {
        try {
            const response = await fetch('/api/platforms');
            const platforms = await response.json();
            
            if (this.platformsGrid) {
                this.platformsGrid.innerHTML = platforms.map(platform => `
                    <div class="platform-card animate-slide-up" style="animation-delay: ${platforms.indexOf(platform) * 0.1}s">
                        <div class="platform-header">
                            <div class="platform-icon-large" style="background: ${platform.color}">
                                <i class="fab fa-${platform.icon}"></i>
                            </div>
                            <div class="platform-name">${platform.name}</div>
                        </div>
                        <div class="platform-formats">
                            ${platform.formats.map(format => 
                                `<span class="format-tag">${format}</span>`
                            ).join('')}
                        </div>
                        <div class="platform-qualities">
                            <small>Quality: ${platform.qualities.join(', ')}</small>
                        </div>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading platforms:', error);
        }
    }
    
    async pasteFromClipboard() {
        try {
            const text = await navigator.clipboard.readText();
            if (this.videoUrlInput) {
                this.videoUrlInput.value = text;
                
                // Validate URL
                this.validateUrl(text);
                
                // Add success animation
                this.pasteBtn.innerHTML = '<i class="fas fa-check"></i>';
                this.pasteBtn.style.background = '#10b981';
                
                setTimeout(() => {
                    this.pasteBtn.innerHTML = '<i class="fas fa-paste"></i>';
                    this.pasteBtn.style.background = '';
                }, 2000);
            }
        } catch (error) {
            console.error('Failed to paste:', error);
            this.showError('Clipboard Error', 'Unable to access clipboard. Please paste manually.');
        }
    }
    
    async validateUrl(url) {
        try {
            const response = await fetch('/api/validate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ url })
            });
            
            const data = await response.json();
            
            if (data.valid && this.downloadBtn) {
                this.downloadBtn.disabled = false;
                this.downloadBtn.innerHTML = `
                    <span class="btn-text">Download from ${data.platform}</span>
                    <span class="btn-icon">
                        <i class="fab fa-${data.icon}"></i>
                    </span>
                `;
                this.downloadBtn.style.background = data.color;
            } else {
                if (this.downloadBtn) {
                    this.downloadBtn.disabled = true;
                    this.downloadBtn.innerHTML = `
                        <span class="btn-text">Unsupported Platform</span>
                        <span class="btn-icon">
                            <i class="fas fa-times"></i>
                        </span>
                    `;
                    this.downloadBtn.style.background = '#6b7280';
                }
            }
        } catch (error) {
            console.error('Validation error:', error);
        }
    }
    
    async processDownload(url = null, quality = null) {
        const videoUrl = url || (this.videoUrlInput ? this.videoUrlInput.value.trim() : '');
        const selectedQuality = quality || (this.qualitySelect ? this.qualitySelect.value : 'best');
        
        if (!videoUrl) {
            this.showError('Input Error', 'Please enter a video URL');
            return;
        }
        
        if (!this.isValidUrl(videoUrl)) {
            this.showError('Invalid URL', 'Please enter a valid video URL');
            return;
        }
        
        // Store for retry
        this.currentDownloadData = { url: videoUrl, quality: selectedQuality };
        
        // Show loading modal
        this.showLoading();
        
        try {
            const response = await fetch('/api/download', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    url: videoUrl, 
                    quality: selectedQuality 
                })
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to download video');
            }
            
            if (data.success && data.data) {
                this.displayResults(data.data);
                this.showToast('Video loaded successfully!');
            } else {
                throw new Error(data.error || 'Download failed');
            }
            
        } catch (error) {
            console.error('Download error:', error);
            this.showError('Download Error', error.message);
        } finally {
            this.hideLoading();
        }
    }
    
    async processDownloadFromUrl(url, quality = 'best') {
        this.currentDownloadData = { url, quality };
        
        try {
            const response = await fetch('/api/download', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ url, quality })
            });
            
            const data = await response.json();
            
            if (data.success && data.data) {
                this.displayResults(data.data);
            } else {
                this.showError('Download Failed', data.error || 'Unable to download video');
            }
        } catch (error) {
            this.showError('Connection Error', 'Unable to connect to server');
        }
    }
    
    isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }
    
    showLoading() {
        if (this.loadingModal) {
            this.loadingModal.classList.add('active');
            
            // Animate progress bar
            const progressFill = document.querySelector('.progress-fill');
            if (progressFill) {
                progressFill.style.animation = 'progress 2s ease-in-out infinite';
            }
        }
    }
    
    hideLoading() {
        if (this.loadingModal) {
            this.loadingModal.classList.remove('active');
            
            // Reset progress bar
            const progressFill = document.querySelector('.progress-fill');
            if (progressFill) {
                progressFill.style.animation = 'none';
            }
        }
    }
    
    showError(title, message) {
        if (this.errorTitle && this.errorMessage) {
            this.errorTitle.textContent = title;
            this.errorMessage.textContent = message;
            if (this.errorModal) {
                this.errorModal.classList.add('active');
            }
        }
    }
    
    showToast(message) {
        if (this.toastMessage && this.successToast) {
            this.toastMessage.textContent = message;
            this.successToast.classList.add('active');
            
            setTimeout(() => {
                this.hideToast();
            }, 3000);
        }
    }
    
    hideToast() {
        if (this.successToast) {
            this.successToast.classList.remove('active');
        }
    }
    
    displayResults(data) {
        // Update video info
        if (this.videoTitle) {
            this.videoTitle.textContent = data.title || 'Video Title';
        }
        
        // Set thumbnail (if available)
        if (data.thumbnail && this.videoThumbnail) {
            this.videoThumbnail.src = data.thumbnail;
            this.videoThumbnail.alt = data.title || 'Video Thumbnail';
        }
        
        // Update metadata
        if (this.videoDuration) {
            this.videoDuration.textContent = data.duration || '0:00';
        }
        
        if (this.videoQuality) {
            this.videoQuality.textContent = data.quality || 'HD';
        }
        
        // Display download options
        this.displayDownloadOptions(data);
        
        // Show results section if it exists
        if (this.resultsSection) {
            this.resultsSection.style.display = 'block';
            
            // Scroll to results
            setTimeout(() => {
                this.resultsSection.scrollIntoView({ behavior: 'smooth' });
            }, 100);
        }
    }
    
    displayDownloadOptions(data) {
        if (!this.downloadOptions) return;
        
        this.downloadOptions.innerHTML = '';
        
        if (!data.media || data.media.length === 0) {
            this.downloadOptions.innerHTML = '<p class="no-options">No download options available</p>';
            return;
        }
        
        data.media.forEach((media, index) => {
            const option = document.createElement('div');
            option.className = 'download-option animate-slide-up';
            option.style.animationDelay = `${index * 0.1}s`;
            
            const quality = media.quality || 'Unknown';
            const format = media.type || 'video';
            const size = media.formatted_size || this.formatFileSize(media.size) || 'Unknown size';
            const url = media.url || '';
            
            option.innerHTML = `
                <div class="option-header">
                    <span class="option-quality">${quality}</span>
                    <span class="option-size">${size}</span>
                </div>
                <div class="option-format">Format: ${format.toUpperCase()}</div>
                <div class="option-resolution">Resolution: ${this.getResolutionFromQuality(quality)}</div>
                <button class="download-option-btn" data-url="${url}" data-filename="${this.sanitizeFilename(data.title || 'video')}">
                    <i class="fas fa-download"></i> Download Now
                </button>
            `;
            
            this.downloadOptions.appendChild(option);
        });
        
        // Also add best video option if available
        if (data.video_best) {
            const best = data.video_best;
            const option = document.createElement('div');
            option.className = 'download-option animate-slide-up best-option';
            option.style.animationDelay = `${data.media.length * 0.1}s`;
            
            const quality = best.quality || 'Best Quality';
            const size = best.formatted_size || this.formatFileSize(best.size) || 'Unknown size';
            const url = best.url || '';
            
            option.innerHTML = `
                <div class="option-header">
                    <span class="option-quality">
                        <i class="fas fa-crown"></i> ${quality}
                    </span>
                    <span class="option-size">${size}</span>
                </div>
                <div class="option-format">Format: MP4 (Recommended)</div>
                <div class="option-resolution">Best available quality</div>
                <button class="download-option-btn best-btn" data-url="${url}" data-filename="${this.sanitizeFilename(data.title || 'video')}">
                    <i class="fas fa-download"></i> Download Best Quality
                </button>
            `;
            
            this.downloadOptions.appendChild(option);
        }
        
        // Add event listeners to download buttons
        this.downloadOptions.querySelectorAll('.download-option-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const url = e.target.dataset.url;
                const filename = e.target.dataset.filename;
                this.downloadFile(url, filename);
            });
        });
    }
    
    getResolutionFromQuality(quality) {
        const resolutions = {
            '144p': '256x144',
            '240p': '426x240',
            '360p': '640x360',
            '480p': '854x480',
            '720p': '1280x720',
            '1080p': '1920x1080',
            '1440p': '2560x1440',
            '2160p': '3840x2160'
        };
        
        for (const [key, value] of Object.entries(resolutions)) {
            if (quality.toLowerCase().includes(key)) {
                return value;
            }
        }
        
        return 'Unknown';
    }
    
    formatFileSize(bytes) {
        if (!bytes || bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    sanitizeFilename(filename) {
        return filename
            .replace(/[<>:"/\\|?*]+/g, '_')
            .replace(/\s+/g, '_')
            .substring(0, 100);
    }
    
    downloadFile(url, filename) {
        if (!url) {
            this.showError('Download Error', 'No download URL available');
            return;
        }
        
        // Create a temporary link
        const link = document.createElement('a');
        link.href = url;
        link.download = filename + '.mp4';
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        
        // Add to document, click, and remove
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Show download animation
        this.showDownloadAnimation();
        
        // Show success message
        this.showToast('Download started!');
        
        // Track download
        this.trackDownload(url);
    }
    
    async trackDownload(url) {
        try {
            await fetch('/api/download', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ url, track: true })
            });
        } catch (error) {
            console.error('Tracking error:', error);
        }
    }
    
    showDownloadAnimation() {
        // Create download animation
        const animation = document.createElement('div');
        animation.className = 'download-animation';
        animation.innerHTML = '<i class="fas fa-download"></i>';
        animation.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0);
            font-size: 4rem;
            color: var(--primary-color);
            z-index: 3000;
            animation: downloadFloat 1s ease-out forwards;
        `;
        
        // Add animation style if not already present
        if (!document.querySelector('#download-animation-style')) {
            const style = document.createElement('style');
            style.id = 'download-animation-style';
            style.textContent = `
                @keyframes downloadFloat {
                    0% {
                        transform: translate(-50%, -50%) scale(0);
                        opacity: 1;
                    }
                    50% {
                        transform: translate(-50%, -50%) scale(1.2);
                        opacity: 1;
                    }
                    100% {
                        transform: translate(-50%, -50%) scale(0);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(animation);
        
        // Remove after animation
        setTimeout(() => {
            animation.remove();
        }, 1000);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.videoDownloader = new VideoDownloader();
});

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VideoDownloader;
}