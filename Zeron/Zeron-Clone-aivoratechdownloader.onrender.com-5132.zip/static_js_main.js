// main js
// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle.querySelector('i');

// Check for saved theme or prefer-color-scheme
const savedTheme = localStorage.getItem('theme') || 
                  (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
document.documentElement.setAttribute('data-theme', savedTheme);
updateThemeIcon(savedTheme);

themeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
    
    // Add animation
    themeToggle.style.transform = 'rotate(360deg)';
    setTimeout(() => {
        themeToggle.style.transform = 'rotate(0deg)';
    }, 300);
});

function updateThemeIcon(theme) {
    themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}

// Mobile Menu Toggle
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.querySelector('.nav-links');

menuToggle.addEventListener('click', () => {
    navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
    navLinks.style.flexDirection = 'column';
    navLinks.style.position = 'absolute';
    navLinks.style.top = '100%';
    navLinks.style.left = '0';
    navLinks.style.right = '0';
    navLinks.style.background = 'var(--bg-card)';
    navLinks.style.padding = '1rem';
    navLinks.style.gap = '1rem';
    navLinks.style.borderBottom = '1px solid var(--border-color)';
    navLinks.style.boxShadow = '0 10px 30px var(--shadow-color)';
});

// Close mobile menu when clicking outside
document.addEventListener('click', (e) => {
    if (!menuToggle.contains(e.target) && !navLinks.contains(e.target)) {
        navLinks.style.display = 'none';
    }
});

// FAQ Accordion
const faqItems = document.querySelectorAll('.faq-item');

faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    
    question.addEventListener('click', () => {
        // Close other items
        faqItems.forEach(otherItem => {
            if (otherItem !== item && otherItem.classList.contains('active')) {
                otherItem.classList.remove('active');
            }
        });
        
        // Toggle current item
        item.classList.toggle('active');
        
        // Add animation
        if (item.classList.contains('active')) {
            item.style.animation = 'none';
            setTimeout(() => {
                item.style.animation = 'slideUp 0.3s ease';
            }, 10);
        }
    });
});

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: 'smooth'
            });
            
            // Close mobile menu if open
            navLinks.style.display = 'none';
        }
    });
});

// Animate elements on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
            
            // Add specific animations based on element type
            if (entry.target.classList.contains('feature-card')) {
                entry.target.style.animationDelay = entry.target.dataset.delay || '0s';
            }
        }
    });
}, observerOptions);

// Observe elements
document.querySelectorAll('.feature-card, .step, .platform-card').forEach(el => {
    observer.observe(el);
});

// Update stats with animation
function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target.toLocaleString() + '+';
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current).toLocaleString() + '+';
        }
    }, 16);
}

// Load stats
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const stats = await response.json();
        
        // Animate counters
        animateCounter(document.getElementById('totalDownloads'), stats.total_downloads);
        animateCounter(document.getElementById('activeUsers'), stats.active_users);
        
        // Success rate
        const successRate = document.getElementById('successRate');
        let current = 0;
        const timer = setInterval(() => {
            current += 0.1;
            if (current >= stats.success_rate) {
                successRate.textContent = stats.success_rate + '%';
                clearInterval(timer);
            } else {
                successRate.textContent = current.toFixed(1) + '%';
            }
        }, 10);
        
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load platforms
async function loadPlatforms() {
    try {
        const response = await fetch('/api/platforms');
        const platforms = await response.json();
        const grid = document.getElementById('platformsGrid');
        
        grid.innerHTML = platforms.map(platform => `
            <div class="platform-card animate-slide-up" style="animation-delay: ${platforms.indexOf(platform) * 0.1}s">
                <div class="platform-header">
                    <div class="platform-icon-large" style="background: ${platform.color}">
                        <i class="fab fa-${platform.icon}"></i>
                    </div>
                    <div class="platform-name">${platform.name}</div>
                </div>
                <div class="platform-formats">
                    ${platform.formats.map(format => 
                        `<span class="format-tag">${format}</span>`
                    ).join('')}
                </div>
                <div class="platform-qualities">
                    <small>Quality: ${platform.qualities.join(', ')}</small>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('Error loading platforms:', error);
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Load dynamic content
    loadStats();
    loadPlatforms();
    
    // Add scroll effect to header
    window.addEventListener('scroll', () => {
        const header = document.querySelector('.header');
        if (window.scrollY > 50) {
            header.style.boxShadow = '0 4px 20px var(--shadow-color)';
        } else {
            header.style.boxShadow = 'none';
        }
    });
    
    // Initialize particles
    if (typeof particlesJS !== 'undefined') {
        particlesJS('particles-js', {
            particles: {
                number: {
                    value: 80,
                    density: {
                        enable: true,
                        value_area: 800
                    }
                },
                color: {
                    value: '#6366f1'
                },
                shape: {
                    type: 'circle'
                },
                opacity: {
                    value: 0.5,
                    random: true
                },
                size: {
                    value: 3,
                    random: true
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: '#6366f1',
                    opacity: 0.2,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 2,
                    direction: 'none',
                    random: true,
                    straight: false,
                    out_mode: 'out',
                    bounce: false
                }
            },
            interactivity: {
                detect_on: 'canvas',
                events: {
                    onhover: {
                        enable: true,
                        mode: 'grab'
                    },
                    onclick: {
                        enable: true,
                        mode: 'push'
                    }
                }
            },
            retina_detect: true
        });
    }
    
    // Add typing animation to hero title
    const heroTitle = document.querySelector('.hero-title');
    const text = heroTitle.textContent;
    heroTitle.textContent = '';
    
    let i = 0;
    const typeWriter = () => {
        if (i < text.length) {
            heroTitle.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 50);
        }
    };
    
    // Start typing animation after a delay
    setTimeout(typeWriter, 1000);
});