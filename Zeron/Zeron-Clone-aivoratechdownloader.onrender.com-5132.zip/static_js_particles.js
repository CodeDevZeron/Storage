// particles effect
/* -----------------------------------------------
/* Author : Vincent Garreau  - vincentgarreau.com
/* MIT license: http://opensource.org/licenses/MIT
/* Demo / Generator : vincentgarreau.com/particles.js
/* GitHub : github.com/VincentGarreau/particles.js
/* How to use? : Check the GitHub README
/* v2.0.0
/* ----------------------------------------------- */

(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["particlesJS"] = factory();
	else
		root["particlesJS"] = factory();
})(this, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: true,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__lib_particles_js__ = __webpack_require__(1);
/* harmony reexport (module object) */ __webpack_require__.d(__webpack_exports__, "particlesJS", function() { return __WEBPACK_IMPORTED_MODULE_0__lib_particles_js__["a"]; });



/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__classes_particles__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__classes_particles_container__ = __webpack_require__(4);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }



/* ---------------------------------------------
  particlesJS
--------------------------------------------- */

var ParticlesJS = function () {
  function ParticlesJS() {
    _classCallCheck(this, ParticlesJS);
  }

  _createClass(ParticlesJS, null, [{
    key: 'load',

    /* ---------- particlesJS functions ---------- */
    value: function load(tag_id, params) {
      /* var selector = document.getElementById(tag_id); */
      return new __WEBPACK_IMPORTED_MODULE_1__classes_particles_container__["a" /* default */](tag_id, params);
    }
  }]);

  return ParticlesJS;
}();

/* harmony export (immutable) */ __webpack_exports__["a"] = ParticlesJS;


/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__particle__ = __webpack_require__(3);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }



/* ---------------------------------------------
  particlesJS
--------------------------------------------- */

var Particles = function () {
  function Particles() {
    _classCallCheck(this, Particles);

    this.particles = [];
  }

  _createClass(Particles, [{
    key: 'init',
    value: function init() {
      this.particles = [];
    }
  }, {
    key: 'push',
    value: function push(particle) {
      this.particles.push(particle);
    }
  }, {
    key: 'update',
    value: function update() {
      for (var i = 0; i < this.particles.length; i++) {
        this.particles[i].update();
      }
    }
  }, {
    key: 'draw',
    value: function draw(ctx) {
      for (var i = 0; i < this.particles.length; i++) {
        this.particles[i].draw(ctx);
      }
    }
  }]);

  return Particles;
}();

/* harmony export (immutable) */ __webpack_exports__["a"] = Particles;


/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/* ---------------------------------------------
  Particle
--------------------------------------------- */

var Particle = function () {
  function Particle() {
    _classCallCheck(this, Particle);

    this.x = 0;
    this.y = 0;
    this.vx = 0;
    this.vy = 0;
    this.color = '';
    this.radius = 0;
    this.opacity = 0;
  }

  _createClass(Particle, [{
    key: 'update',
    value: function update() {
      this.x += this.vx;
      this.y += this.vy;
    }
  }, {
    key: 'draw',
    value: function draw(ctx) {
      ctx.save();
      ctx.globalAlpha = this.opacity;
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }]);

  return Particle;
}();

/* harmony export (immutable) */ __webpack_exports__["a"] = Particle;


/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__classes_particles__ = __webpack_require__(2);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }



/* ---------------------------------------------
  ParticlesContainer
--------------------------------------------- */

var ParticlesContainer = function () {
  function ParticlesContainer(tag_id, params) {
    _classCallCheck(this, ParticlesContainer);

    this.tag_id = tag_id;
    this.canvas = null;
    this.ctx = null;
    this.particles = new __WEBPACK_IMPORTED_MODULE_0__classes_particles__["a" /* default */]();
    this.params = params || {};
    this.init();
  }

  _createClass(ParticlesContainer, [{
    key: 'init',
    value: function init() {
      var _this = this;

      /* Create canvas */
      this.canvas = document.createElement('canvas');
      this.ctx = this.canvas.getContext('2d');
      
      /* Style canvas */
      this.canvas.style.position = 'fixed';
      this.canvas.style.top = '0';
      this.canvas.style.left = '0';
      this.canvas.style.width = '100%';
      this.canvas.style.height = '100%';
      this.canvas.style.zIndex = '-1';
      this.canvas.style.pointerEvents = 'none';
      
      /* Append to container */
      var container = document.getElementById(this.tag_id);
      if (container) {
        container.appendChild(this.canvas);
      } else {
        document.body.appendChild(this.canvas);
      }
      
      /* Set canvas size */
      this.resize();
      window.addEventListener('resize', function () {
        return _this.resize();
      });
      
      /* Create particles */
      this.createParticles();
      
      /* Start animation */
      this.animate();
    }
  }, {
    key: 'resize',
    value: function resize() {
      this.canvas.width = window.innerWidth;
      this.canvas.height = window.innerHeight;
    }
  }, {
    key: 'createParticles',
    value: function createParticles() {
      var count = this.params.particles && this.params.particles.number && this.params.particles.number.value || 50;
      
      for (var i = 0; i < count; i++) {
        var particle = {
          x: Math.random() * this.canvas.width,
          y: Math.random() * this.canvas.height,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          radius: Math.random() * 3 + 1,
          color: this.params.particles && this.params.particles.color && this.params.particles.color.value || '#6366f1',
          opacity: Math.random() * 0.5 + 0.2
        };
        
        this.particles.push(particle);
      }
    }
  }, {
    key: 'animate',
    value: function animate() {
      var _this2 = this;

      /* Clear canvas */
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      
      /* Update and draw particles */
      for (var i = 0; i < this.particles.length; i++) {
        var p = this.particles[i];
        
        /* Update position */
        p.x += p.vx;
        p.y += p.vy;
        
        /* Bounce off walls */
        if (p.x < 0 || p.x > this.canvas.width) p.vx = -p.vx;
        if (p.y < 0 || p.y > this.canvas.height) p.vy = -p.vy;
        
        /* Keep within bounds */
        p.x = Math.max(0, Math.min(this.canvas.width, p.x));
        p.y = Math.max(0, Math.min(this.canvas.height, p.y));
        
        /* Draw particle */
        this.ctx.globalAlpha = p.opacity;
        this.ctx.fillStyle = p.color;
        this.ctx.beginPath();
        this.ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        this.ctx.fill();
      }
      
      /* Draw connections */
      this.drawConnections();
      
      /* Continue animation */
      requestAnimationFrame(function () {
        return _this2.animate();
      });
    }
  }, {
    key: 'drawConnections',
    value: function drawConnections() {
      var maxDistance = 150;
      
      for (var i = 0; i < this.particles.length; i++) {
        for (var j = i + 1; j < this.particles.length; j++) {
          var p1 = this.particles[i];
          var p2 = this.particles[j];
          
          var dx = p1.x - p2.x;
          var dy = p1.y - p2.y;
          var distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < maxDistance) {
            var opacity = 1 - distance / maxDistance;
            this.ctx.strokeStyle = 'rgba(99, 102, 241, ' + opacity * 0.2 + ')';
            this.ctx.lineWidth = 1;
            this.ctx.beginPath();
            this.ctx.moveTo(p1.x, p1.y);
            this.ctx.lineTo(p2.x, p2.y);
            this.ctx.stroke();
          }
        }
      }
    }
  }]);

  return ParticlesContainer;
}();

/* harmony export (immutable) */ __webpack_exports__["a"] = ParticlesContainer;


/***/ })
/******/ ]);
});