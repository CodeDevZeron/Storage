        function redirectToSearch(event) {
            event.preventDefault();
            const searchInput = document.getElementById('searchInput');
            const searchTerm = encodeURIComponent(searchInput.value.trim());
            if (searchTerm) {
                const searchUrl = `https://movienestbd.click/search?q=${searchTerm}`;
                window.open(searchUrl, '_blank');
            }
            return false;
        }