import{ab as o,L as a,Q as i}from"./Bijw-FCU.js";const t=o(e=>{const n=a("token");if(a("user"),!n.value&&(e==null?void 0:e.name)!=="login")return i("/login")});export{t as default};
