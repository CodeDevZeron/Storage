(function () {
  /**
   * scrollspy
   */
  var scrollSpy = new bootstrap.ScrollSpy(document.body, {
    target: "#spyThroughThis",
  });

  /**
   * comment system
   */
  const addCommnetBtns = document.querySelectorAll(
    ".user-reviews .title.foot .comment"
  );

  addCommnetBtns.forEach(function (commentBtn) {
    commentBtn.addEventListener("click", function () {
      const commentField = this.parentElement.parentElement.nextElementSibling;

      commentField.classList.toggle("active");
    });
  });

  const toggleCommentBtn = document.querySelectorAll(".comment-triger");

  toggleCommentBtn.forEach(function (btn) {
    btn.addEventListener("click", function () {
      this.nextElementSibling.classList.toggle("active");
    });
  });

  // reply other's comment
  const replyButtons = document.querySelectorAll('.foot .reply-btn');
  
  replyButtons.forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      
      const replyField = this.parentElement.nextElementSibling;
      
      replyField.classList.toggle('active');
    });
  });
  
  // report spam comments
  const reportButtons = document.querySelectorAll('.foot .report-btn');

  reportButtons.forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();

      alert('Reported spam!');
    });
  });
})();
