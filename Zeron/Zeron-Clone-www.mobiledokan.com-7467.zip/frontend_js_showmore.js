(function () {
  /*
   * price list read more animation
   */
  const readAllBtn = document.querySelector(".readall-button");

  readAllBtn.addEventListener("click", function () {
    const wrapper = document.querySelector(".readall-wrapper .readall");
    const content = document.querySelector(".readall-wrapper .readall p");
    let buttonText = document.querySelector(".readall-button .toggle-text");
    let doubleArrow = document.querySelector(".readall-button .bi");

    const wrapplerClasses = wrapper.classList;
    const contentHeight = content.clientHeight;

    if (wrapper.style.height === 'auto') {
      wrapper.style.height = `150px`;
      buttonText.textContent = "More";
      wrapplerClasses.add("readall-hide");
      this.classList.remove("active");
      doubleArrow.classList.remove("active");
    } else {
      wrapper.style.height = 'auto';
      buttonText.textContent = "Less";
      wrapplerClasses.remove("readall-hide");
      this.classList.add("active");
      doubleArrow.classList.add("active");
    }
  });
})();
