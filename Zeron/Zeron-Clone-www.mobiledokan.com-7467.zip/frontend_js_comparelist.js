// function comparelist(id) {
//     var existingArray = getCookieArray('compareList');
//     if (!existingArray) {
//         existingArray = [];
//     }
//     if (existingArray.indexOf(id) === -1) {
//         existingArray.push(id);
//     }
//     setCookieArray('compareList', existingArray);
//     console.log(getCookieArray('compareList'))
// }

// function setCookieArray(name, value, days) {
//     var expires = '';
//     if (days) {
//         var date = new Date();
//         date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
//         expires = '; expires=' + date.toUTCString();
//     }
//     document.cookie = name + '=' + JSON.stringify(value) + expires + '; path=/';
// }

// // Example usage to set a cookie that expires in 30 days:
// var myArray = [1, 2, 3];
// setCookieArray('compareList', myArray, 30);


// function getCookieArray(name) {
//     var nameEQ = name + '=';
//     var ca = document.cookie.split(';');
//     for (var i = 0; i < ca.length; i++) {
//         var c = ca[i];
//         while (c.charAt(0) === ' ') {
//             c = c.substring(1, c.length);
//         }
//         if (c.indexOf(nameEQ) === 0) {
//             return JSON.parse(c.substring(nameEQ.length, c.length));
//         }
//     }
//     return null;
// }
// console.log(getCookieArray('compareList'))
