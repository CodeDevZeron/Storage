(function () {
  /*
   * header js
   */
  const menuIcon = document.querySelector(".sm-nav-icon");
  const closeMenuIcon = document.querySelector(".sm-nav-close-icon");
  const collectionDropBtns = document.querySelectorAll(".main-navbar .nav-item.drop-menu");
  
  menuIcon.addEventListener("click", function () {
      const navbar = document.querySelector(".main-navbar");
      navbar.classList.add("active");
  });
  
  closeMenuIcon.addEventListener("click", function () {
      const navbar = document.querySelector(".main-navbar");
      navbar.classList.remove("active");
  });
  
  collectionDropBtns.forEach(dropBtn => {
      dropBtn.addEventListener("click", function () {
          // Remove "active" class from all drop menus
          const allDropMenus = document.querySelectorAll(".drop-menu .dropdown-menu");
          allDropMenus.forEach(dropMenu => {
              dropMenu.classList.remove("active");
          });
  
          // Remove "active" class from all arrows
          const allArrows = document.querySelectorAll(".main-navbar .nav-item.drop-menu .dropdown-right-arrow");
          allArrows.forEach(arrow => {
              arrow.classList.remove("active");
          });
  
          // Add "active" class to the clicked drop menu and arrow
          const dropMenu = this.querySelector('.dropdown-menu');
          const arrow = this.querySelector('.dropdown-right-arrow');
          dropMenu.classList.toggle("active");
          arrow.classList.toggle("active");
      });
  });
  
  const compareTriggerBtn = document.querySelector('.compare-trigger-btn');
  if(compareTriggerBtn){
 
  const compareCloseBtn = document.querySelector('#compare-sidebar .btn-close');

  compareTriggerBtn.addEventListener('click', function () {
    this.classList.toggle('active');
  });
  compareCloseBtn.addEventListener('click', function () {
    const compareBtnClasses = compareTriggerBtn.classList;
    if (compareBtnClasses.contains('active')) {
      compareBtnClasses.remove('active');
    }
  });

}



})();
