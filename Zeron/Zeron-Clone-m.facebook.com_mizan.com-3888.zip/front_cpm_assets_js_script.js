document.querySelectorAll(".dropdown-toggle").forEach((item) => {
  item.addEventListener("click", (event) => {
    if (event.target.classList.contains("dropdown-toggle")) {
      event.target.classList.toggle("toggle-change");
    } else if (
      event.target.parentElement.classList.contains("dropdown-toggle")
    ) {
      event.target.parentElement.classList.toggle("toggle-change");
    }
  });
});

$(document).ready(function () {
  $(".megamenu").on("click", function (e) {
    e.stopPropagation();
  });
});

$(document).ready(function () {
  $(".hamburger").click(function () {
    $(this).toggleClass("is-active");
  });
});

function clickFunction() {
  var para = document.getElementById("toggle-icon");
  para.classList.toggle("rotate-icon");
}

function toggleIcon(e) {
  $(e.target)
    .prev(".panel-heading")
    .find(".more-less")
    .toggleClass("glyphicon-plus glyphicon-minus");
}
$(".panel-group").on("hidden.bs.collapse", toggleIcon);
$(".panel-group").on("shown.bs.collapse", toggleIcon);

$(document).ready(function () {
  $(".btn-urutkan").click(function () {
    $(".urutkan").toggleClass("d-none d-flex");
  });

  $(".urutkan > a").click(function () {
    $(".urutkan").toggleClass("d-none d-flex");
  });
});

$(document).ready(function () {
  $(".btn-kategorikan").click(function () {
    $(".kategorikan").toggleClass("d-none d-flex");
  });

  $(".kategorikan > a").click(function () {
    $(".kategorikan").toggleClass("d-none d-flex");
  });
});

$(document).ready(function () {
  var dropToggle = $(".dropdown-menu > .dropdown-toggle");
  // Click event
  dropToggle.click(function (e) {
    // Prevents the event from bubbling up the DOM
    e.stopPropagation();

    // New var 'expanded' to the check the 'aria-expanded' attribute
    var expanded = $(this).attr("aria-expanded");
    //  Inline if to set 'aria-expanded' to true if it was false
    $(this).attr("aria-expanded", expanded === "false" ? "true" : "false");
    // Show the next element which is your dropdown menu
    $(this).next().toggleClass("show");
  });
});




$(document).ready(function () {
  $(".collapse-toggle-tb").click(function () {
    $('#titikterang').collapse('hide')
  });
})

$(document).ready(function () {
  $("#getproduct").click(function () {
    $("#cv-getproduct").toggleClass("cevron-up");
  });
  $("#m-tokopedia").click(function () {
    $("#cv-tokopedia").toggleClass("cevron-down");
  });
})