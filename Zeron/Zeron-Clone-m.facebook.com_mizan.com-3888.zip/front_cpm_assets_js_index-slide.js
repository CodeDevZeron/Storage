$(document).ready(function () {
  let i = 0;

  const wait = (ms) => new Promise((res) => setTimeout(res, ms));

  async function loop() {
    var total_content = $('#total_content').val();
    i++;
    heroActive(i);
    await wait(5000);
    if (i == total_content) {
      i = 0;
      loop();
    } else {
      loop();
    }
  }

  loop();

  function heroActive(i) {
    var total_content = $('#total_content').val();
    if (window.matchMedia("(max-width: 576px)").matches) {
    } else {
      if (i > 1) {
        $(".hero-load-title").text($("#hero-load-" + i)[0].innerText);
        $(".hero-load-desc").html($('#hero-desc-' + i)[0].innerHTML);
        $(".hero-load-date").text($("#hero-date-" + i)[0].innerText);
        $("#hero-load-image").attr('src', $("#hero-image-" + i)[0].innerText);
        $("#loader-" + (i - 1) ).html("");
        $('#loader-' + i).html('<span class="lds-ring"><span></span><span></span><span></span><span></span></span>');
        $("#hero-load-" + (i - 1)).removeClass("hero-load-active");
        $("#hero-load-" + i).addClass("hero-load-active");
      }
      if (i === 1) {
        $(".hero-load-title").text($("#hero-load-" + "1")[0].innerText);
        $("#hero-load-image").attr('src', $("#hero-image-1")[0].innerText);
        $("#loader-" + total_content).html("");
        $('#loader-' + i).html('<span class="lds-ring"><span></span><span></span><span></span><span></span></span>');
        $("#hero-load-" + "1").addClass("hero-load-active");
        $("#hero-load-" + total_content).removeClass("hero-load-active");
      }
    }
  }
});
