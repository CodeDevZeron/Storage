const SUPABASE_URL = 'https://wslbofcykxtjnkoimbaj.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_JdGo6HvSSVcL-cs-wx8L1g_tdfRVTHF';

const AD_CONFIG = {
  adLink:         'https://omg10.com/4/10975591',
  smartlink:      'https://omg10.com/4/10975592',
  directlink:     'https://omg10.com/4/10975594',
  robotSmartlink: 'https://omg10.com/4/10975592',
};

const SITE_CONFIG = {
  telegramChannel: 'https://t.me/smnXzone',
  telegramDev:     'https://t.me/smn_admin',
  websiteUrl:      'https://smnxzone.netlify.app',
  siteName:        'smnXzone',
  adminPassword:   'admin123',
};
