(() => {
    // Only initialize if in PWA mode
    // if (!window.matchMedia('(display-mode: standalone)').matches) {
    //     return;
    // }

    let progressInterval;
    const loader = document.getElementById('pwa-loader');
    const progressBar = loader?.querySelector('.progress-bar');

    function startProgress() {
        if (!loader || !progressBar) return;

        let width = 0;
        loader.classList.remove('hidden', 'd-none');

        progressInterval = setInterval(() => {
            if (width >= 90) {
                clearInterval(progressInterval);
                return;
            }

            width += (90 - width) * 0.1;
            progressBar.style.width = width + '%';
        }, 100);
    }

    function completeProgress() {
        if (!loader || !progressBar) return;

        clearInterval(progressInterval);
        progressBar.style.width = '100%';

        setTimeout(() => {
            loader.classList.add('hidden');
            progressBar.style.width = '0%';
        }, 200);
    }

    // Listen for navigation events
    document.addEventListener('click', (e) => {
        const link = e.target.closest('a');
        if (!link) return;

        // Only handle internal links
        if (
            link.href &&
            link.href.startsWith(window.location.origin) &&
            !link.hasAttribute('download') &&
            !link.target &&
            !e.ctrlKey &&
            !e.shiftKey &&
            !e.metaKey
        ) {
            startProgress();
        }
    });

    // Handle browser back/forward
    window.addEventListener('popstate', startProgress);

    // Complete progress when page loads
    window.addEventListener('load', completeProgress);

    // Handle form submissions
    // document.addEventListener('submit', (e) => {
    //     const form = e.target;
    //     // Show loader for both GET and POST methods
    //     startProgress();
    // });

    // Handle Livewire events
    document.addEventListener('livewire:init', () => {
        Livewire.hook('morph.updating', () => {
            startProgress();
        });
        
        Livewire.hook('morph.updated', () => {
            completeProgress();
        });
        
        Livewire.hook('request.finished', () => {
            completeProgress();
        });
    });
})();
