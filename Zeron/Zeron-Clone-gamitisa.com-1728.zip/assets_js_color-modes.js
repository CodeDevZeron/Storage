(() => {
  "use strict";

  const getStoredTheme = () => localStorage.getItem("theme");
  const setStoredTheme = (theme) => localStorage.setItem("theme", theme);

  if (!getStoredTheme()) {
    setStoredTheme("system");
  }

  const getPreferredTheme = () => {
    const storedTheme = getStoredTheme();
    if (storedTheme) {
      return storedTheme;
    }

    return window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  };

  const setTheme = (theme) => {
    const actualTheme = theme === "system" 
      ? (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")
      : theme;
    
    // Set data-bs-theme for Bootstrap compatibility
    document.documentElement.setAttribute("data-bs-theme", actualTheme);
    
    // Add/remove dark class for Tailwind CSS
    if (actualTheme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  setTheme(getPreferredTheme());

  const showActiveTheme = (theme, focus = false) => {
    const themeSwitcher = document.querySelector("#bd-theme");
    const activeThemeIcon = document.querySelector(".theme-icon-active");

    if (!themeSwitcher || !activeThemeIcon) {
      console.log('showActiveTheme: Elements not found', { 
        themeSwitcher: !!themeSwitcher, 
        activeThemeIcon: !!activeThemeIcon,
        theme: theme
      });
      return;
    }
    
    try {
      // Define theme icons and labels
      const themeConfig = {
        light: { icon: "bi-sun-fill", label: "Light" },
        dark: { icon: "bi-moon-stars-fill", label: "Dark" },
        system: { icon: "bi-circle-half", label: "System" }
      };
      
      const config = themeConfig[theme] || themeConfig.system;
      
      // Update the icon
      activeThemeIcon.className = `bi ${config.icon} my-1 theme-icon-active`;
      activeThemeIcon.dataset.icon = config.icon;
      
      // Update aria-label and title
      const themeSwitcherLabel = `Toggle theme (${config.label})`;
      themeSwitcher.setAttribute("aria-label", themeSwitcherLabel);
      themeSwitcher.setAttribute("title", themeSwitcherLabel);

      if (focus) {
        themeSwitcher.focus();
      }
    } catch (error) {
      console.error('Error in showActiveTheme:', error);
    }
  };

  // Update theme when user changes OS theme
  window
    .matchMedia("(prefers-color-scheme: dark)")
    .addEventListener("change", () => {
      const storedTheme = getStoredTheme();

      if (storedTheme !== "light" && storedTheme !== "dark") {
        setTheme(getPreferredTheme());
      }
    });

  // Toggle theme function for click cycling
  window.toggleTheme = () => {
    const currentTheme = getStoredTheme();
    let nextTheme;
    
    // Cycle through: light → dark → system → light
    switch (currentTheme) {
      case "light":
        nextTheme = "dark";
        break;
      case "dark":
        nextTheme = "system";
        break;
      case "system":
      default:
        nextTheme = "light";
        break;
    }
    
    setStoredTheme(nextTheme);
    setTheme(nextTheme);
    showActiveTheme(nextTheme, true);
  };

  // Function to initialize theme switcher when elements are ready
  const initializeThemeSwitcher = () => {
    const currentTheme = getPreferredTheme();
    const themeSwitcher = document.querySelector("#bd-theme");
    const activeThemeIcon = document.querySelector(".theme-icon-active");
    
    if (themeSwitcher && activeThemeIcon) {
      showActiveTheme(currentTheme);
      return true;
    }
    return false;
  };

  // Try to initialize immediately if DOM is already loaded
  if (document.readyState === 'loading') {
    document.addEventListener("DOMContentLoaded", () => {
      // Try multiple times with increasing delays
      setTimeout(() => {
        if (!initializeThemeSwitcher()) {
          setTimeout(() => {
            if (!initializeThemeSwitcher()) {
              setTimeout(initializeThemeSwitcher, 1000);
            }
          }, 500);
        }
      }, 100);
    });
  } else {
    // DOM is already loaded, try immediately
    setTimeout(initializeThemeSwitcher, 100);
  }
})();
