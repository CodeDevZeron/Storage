(() => {
    function updateThemeColor() {
        const themeColorMeta = document.querySelector('meta[name="theme-color"]');
        if (!themeColorMeta) return;

        const navbar = document.querySelector('#navbar');
        if (!navbar) return;

        // Force a reflow to ensure styles are computed
        navbar.offsetHeight;

        // Check if we're on the homepage
        const isHomepage = window.location.pathname === '/' || window.location.pathname === '/index.php';
        
        // Check if dark mode is active
        const isDarkMode = document.documentElement.classList.contains('dark');

        if (isHomepage) {
            // For homepage, use appropriate background color since navbar is transparent
            const themeColor = isDarkMode ? '#111827' : '#ffffff'; // gray-900 : white
            themeColorMeta.setAttribute('content', themeColor);
        } else {
            // For other pages, use navbar background color
            // Navbar uses bg-white/90 dark:bg-gray-900/90 with backdrop-blur
            const themeColor = isDarkMode ? '#111827' : '#ffffff'; // gray-900 : white
            themeColorMeta.setAttribute('content', themeColor);
        }
    }

    // Update theme color when the page loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => setTimeout(updateThemeColor, 10));
    } else {
        setTimeout(updateThemeColor, 10);
    }

    // Listen for theme button clicks
    const themeToggle = document.querySelector('#bd-theme');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            // Wait for Tailwind theme to apply
            setTimeout(updateThemeColor, 300);
        });
    }

    // Update when system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
        const storedTheme = localStorage.getItem('theme');
        if (storedTheme === 'system') {
            setTimeout(updateThemeColor, 300);
        }
    });

    // Watch for theme class changes (Tailwind dark mode)
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'class' && mutation.target === document.documentElement) {
                setTimeout(updateThemeColor, 300);
            }
        });
    });

    observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['class']
    });
})();
