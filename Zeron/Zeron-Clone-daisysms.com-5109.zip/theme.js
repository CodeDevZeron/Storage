const themeToggle = document.getElementById("theme-controller");

function applyTheme(theme) {
	document
		.querySelectorAll("[data-theme]")
		.forEach((el) => el.setAttribute("data-theme", theme));
	localStorage.setItem("theme", theme);
}

themeToggle.addEventListener("change", function () {
	const theme = this.checked ? "dark" : "light";
	applyTheme(theme);
});

const savedTheme = localStorage.getItem("theme") || "light";
applyTheme(savedTheme);
themeToggle.checked = savedTheme === "dark";
