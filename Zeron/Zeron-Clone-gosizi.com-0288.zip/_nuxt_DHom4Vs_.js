import{a9 as o,K as a,P as i}from"./BJU8HcT8.js";const t=o(e=>{const n=a("token");if(a("user"),!n.value&&(e==null?void 0:e.name)!=="login")return i("/login")});export{t as default};
